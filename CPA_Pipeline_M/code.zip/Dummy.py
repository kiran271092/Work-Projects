import sys
#print('Number of arguments:', len(sys.argv),'arguments.')
#print('Argument List:', str(sys.argv))
print(sys.argv[1],type(sys.argv[1]))
print("r'"+sys.argv[1]+"'")
print(sys.argv[2],type(list(sys.argv[2])))